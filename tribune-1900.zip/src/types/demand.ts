export interface ClubDemand {
  id?: string;
  firstName: string;
  lastName: string;
  email: string;
  phone?: string;
  sport: string;
  clubName: string;
  clubCity: string;
  size: string;
  sizeType: 'homme' | 'femme';
  jerseyTypes: ('historic' | 'collector')[];
  comment?: string;
  notifyAvailable: boolean;
  acceptContact: boolean;
  createdAt?: Date;
  status?: 'pending' | 'contacted_club' | 'available' | 'fulfilled';
}

export const SPORTS = [
  'Football',
  'Rugby',
  'Basket',
  'Handball',
  'Autre',
] as const;

export const SIZES = ['XS', 'S', 'M', 'L', 'XL', 'XXL'] as const;

export const JERSEY_TYPES = [
  { value: 'historic', label: 'Maillot historique (utilisé)', description: 'Authentique pièce d\'histoire portée en compétition' },
  { value: 'collector', label: 'Maillot collector', description: 'Stocks officiels ou création en collaboration avec le club' },
] as const;
