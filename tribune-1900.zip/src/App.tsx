import TribuneHeader from './components/TribuneHeader';
import TribuneHero from './components/TribuneHero';
import ConceptSection from './components/ConceptSection';
import DemandCallout from './components/DemandCallout';
import DemandForm from './components/DemandForm';
import HowItWorks from './components/HowItWorks';
import ScarcitySection from './components/ScarcitySection';
import TribuneFooter from './components/TribuneFooter';
import { ClubDemand } from './types/demand';
import { supabase } from './lib/supabase';

function App() {
  const scrollToForm = () => {
    const formElement = document.getElementById('form');
    formElement?.scrollIntoView({ behavior: 'smooth' });
  };

  const handleDemandSubmit = async (demand: ClubDemand) => {
    const jerseyTypesLabel = demand.jerseyTypes.length === 0
      ? 'Non spécifié'
      : demand.jerseyTypes.map(t => t === 'historic' ? 'Historique' : 'Collector').join(' + ');

    const { error } = await supabase.from('demand_responses').insert({
      email: demand.email,
      interest_level: demand.sport,
      budget: demand.size,
      occasion: `${demand.clubName} - ${demand.clubCity}`,
      style_preference: `${jerseyTypesLabel} - ${demand.sizeType}`,
      jersey_types: demand.jerseyTypes,
      additional_notes: `${demand.firstName} ${demand.lastName} | ${demand.phone || 'No phone'} | ${demand.comment || 'No comment'}`,
    });

    if (error) {
      console.error('Error saving demand:', error);
      throw error;
    }
  };

  return (
    <div className="min-h-screen bg-tribune-white">
      <TribuneHeader />

      <TribuneHero onCTAClick={scrollToForm} />

      <ConceptSection />

      <DemandCallout onCTAClick={scrollToForm} />

      <HowItWorks />

      <DemandForm onSubmit={handleDemandSubmit} />

      <ScarcitySection />

      <TribuneFooter />
    </div>
  );
}

export default App;
