interface DemandCalloutProps {
  onCTAClick: () => void;
}

export default function DemandCallout({ onCTAClick }: DemandCalloutProps) {
  return (
    <section className="bg-tribune-black py-16 sm:py-24">
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
        <h2 className="text-3xl sm:text-4xl md:text-5xl font-serif text-tribune-white mb-6 sm:mb-8 leading-tight px-2">
          Et si votre club était le prochain ?
        </h2>

        <div className="max-w-2xl mx-auto space-y-5 sm:space-y-6 mb-10 sm:mb-12">
          <p className="text-base sm:text-lg text-tribune-white/80 leading-relaxed px-2">
            Indiquez-nous le club que vous souhaitez voir disponible sur Tribune 1900.
            Si la demande est suffisante, nous contacterons directement le club.
          </p>

          <div className="border-l-4 border-tribune-white bg-tribune-white/5 p-4 sm:p-6 text-left">
            <p className="text-base sm:text-lg text-tribune-white font-serif mb-2">
              Aucun paiement aujourd'hui.
            </p>
            <p className="text-sm sm:text-base text-tribune-white/60 font-light">
              Vous manifestez simplement votre intérêt.
            </p>
          </div>
        </div>

        <button
          onClick={onCTAClick}
          className="inline-flex items-center justify-center px-6 sm:px-10 py-3 sm:py-4 bg-tribune-black hover:bg-tribune-black/90 text-tribune-white font-bold text-base sm:text-lg tracking-wide transition-all border-2 border-tribune-white w-full sm:w-auto max-w-md"
        >
          Je manifeste mon intérêt
        </button>
      </div>
    </section>
  );
}
