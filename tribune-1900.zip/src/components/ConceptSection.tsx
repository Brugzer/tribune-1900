import { Check } from 'lucide-react';

export default function ConceptSection() {
  const benefits = [
    'Porter une pièce collector unique',
    'Soutenir directement un club amateur',
    'Célébrer l\'histoire locale',
    'Posséder un maillot historique ou une création exclusive',
  ];

  return (
    <section className="bg-tribune-beige py-16 sm:py-24">
      <div className="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-12 sm:mb-16">
          <h2 className="text-3xl sm:text-4xl md:text-5xl font-serif text-tribune-black mb-6 leading-tight px-2">
            Des maillots collectors qui racontent une histoire.
          </h2>
        </div>

        <div className="max-w-3xl mx-auto space-y-4 sm:space-y-6 mb-10 sm:mb-12">
          <p className="text-base sm:text-lg text-tribune-black/80 leading-relaxed">
            Tribune 1900 conçoit des maillots uniques en collaboration avec les clubs amateurs.
            Rééditions de maillots historiques ou créations originales, chaque design célèbre l'histoire, les couleurs et le patrimoine local — des éditions limitées pensées comme des pièces collectors.
          </p>

          <p className="text-lg sm:text-xl text-tribune-black font-serif">
            Commander un maillot Tribune 1900, c'est :
          </p>
        </div>

        <div className="grid sm:grid-cols-2 gap-3 sm:gap-4 max-w-3xl mx-auto mb-10 sm:mb-12">
          {benefits.map((benefit, index) => (
            <div
              key={index}
              className="flex items-start space-x-3 bg-tribune-white/50 border border-tribune-black/20 p-3 sm:p-4"
            >
              <Check className="w-5 h-5 text-tribune-black flex-shrink-0 mt-0.5 sm:mt-1" />
              <span className="text-sm sm:text-base text-tribune-black font-light">{benefit}</span>
            </div>
          ))}
        </div>

        <div className="text-center px-4">
          <button
            onClick={() => {
              const formElement = document.getElementById('form');
              formElement?.scrollIntoView({ behavior: 'smooth' });
            }}
            className="inline-flex items-center justify-center px-6 sm:px-10 py-3 sm:py-4 bg-tribune-black hover:bg-tribune-black/90 text-tribune-white font-bold text-base sm:text-lg tracking-wide transition-all w-full sm:w-auto max-w-md"
          >
            Demander le maillot de mon club
          </button>
        </div>
      </div>
    </section>
  );
}
