import { AlertCircle } from 'lucide-react';

export default function ScarcitySection() {
  return (
    <section className="bg-tribune-black py-16 sm:py-24">
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-10 sm:mb-12">
          <h2 className="text-3xl sm:text-4xl md:text-5xl font-serif text-tribune-white mb-6 sm:mb-8 leading-tight px-2">
            Des éditions limitées et exclusives.
          </h2>

          <div className="max-w-2xl mx-auto space-y-5 sm:space-y-6">
            <p className="text-base sm:text-lg text-tribune-white/80 leading-relaxed px-2">
              Chaque maillot Tribune 1900 est co-créé avec les clubs amateurs.
              Éditions limitées en quantité — une fois épuisées, elles ne reviennent pas.
            </p>

            <div className="bg-tribune-white/5 border-l-4 border-tribune-white p-4 sm:p-6">
              <div className="flex items-start space-x-3">
                <AlertCircle className="w-5 h-5 sm:w-6 sm:h-6 text-tribune-white flex-shrink-0 mt-0.5 sm:mt-1" />
                <p className="text-sm sm:text-base text-tribune-white font-serif text-left">
                  Conception collaborative avec les clubs — authenticité garantie.
                </p>
              </div>
            </div>
          </div>
        </div>

        <div className="grid sm:grid-cols-3 gap-4 sm:gap-6 max-w-3xl mx-auto mt-10 sm:mt-12">
          <div className="text-center p-4 sm:p-6 bg-tribune-white/5 border border-tribune-white/10">
            <div className="text-2xl sm:text-3xl font-serif text-tribune-white mb-2">
              Co-création
            </div>
            <div className="text-tribune-white/60 text-xs sm:text-sm font-light">
              Avec les clubs
            </div>
          </div>

          <div className="text-center p-4 sm:p-6 bg-tribune-white/5 border border-tribune-white/10">
            <div className="text-2xl sm:text-3xl font-serif text-tribune-white mb-2">
              Authentique
            </div>
            <div className="text-tribune-white/60 text-xs sm:text-sm font-light">
              Histoire respectée
            </div>
          </div>

          <div className="text-center p-4 sm:p-6 bg-tribune-white/5 border border-tribune-white/10">
            <div className="text-2xl sm:text-3xl font-serif text-tribune-white mb-2">
              Édition limitée
            </div>
            <div className="text-tribune-white/60 text-xs sm:text-sm font-light">
              Quantités restreintes
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
