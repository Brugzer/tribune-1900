import { ChevronDown } from 'lucide-react';

interface TribuneHeroProps {
  onCTAClick: () => void;
}

export default function TribuneHero({ onCTAClick }: TribuneHeroProps) {
  return (
    <section className="relative min-h-screen flex items-center justify-center overflow-hidden bg-tribune-white pt-16 sm:pt-20 px-4">
      <div className="relative z-10 max-w-4xl mx-auto sm:px-6 lg:px-8 text-center">
        <div className="mb-6 sm:mb-8">
          <div className="inline-block border border-tribune-black px-4 py-2 mb-6 sm:mb-8">
            <span className="text-tribune-black font-serif text-xs sm:text-sm tracking-[0.2em] sm:tracking-[0.3em] uppercase">
              Patrimoine Sportif
            </span>
          </div>
        </div>

        <h1 className="text-3xl sm:text-5xl md:text-6xl lg:text-7xl font-serif text-tribune-black mb-6 sm:mb-8 leading-[1.15] sm:leading-[1.1] px-2">
          Les maillots amateurs ont une histoire.
        </h1>

        <p className="text-base sm:text-xl md:text-2xl text-tribune-black/80 mb-8 sm:mb-12 max-w-3xl mx-auto leading-relaxed font-light px-2">
          Tribune 1900 crée des maillots uniques designés avec l'histoire des clubs amateurs — rééditions historiques et pièces collectors authentiques.
          <span className="block mt-4 sm:mt-6 text-tribune-black font-normal">
            Portez les couleurs de votre club dans une édition exclusive qui célèbre son patrimoine.
          </span>
        </p>

        <button
          onClick={onCTAClick}
          className="group relative inline-flex items-center justify-center px-6 sm:px-10 py-3 sm:py-4 bg-tribune-black hover:bg-tribune-black/90 text-tribune-white font-bold text-base sm:text-lg tracking-wide transition-all w-full sm:w-auto max-w-md mx-auto"
        >
          <span className="text-center">Je veux le maillot de mon club</span>
          <ChevronDown className="ml-2 w-5 h-5 group-hover:translate-y-1 transition-transform flex-shrink-0" />
        </button>

        <p className="text-tribune-black/50 text-xs sm:text-sm mt-6 sm:mt-8 font-light tracking-wide px-2">
          Aucun paiement • Manifestation d'intérêt uniquement
        </p>
      </div>
    </section>
  );
}
