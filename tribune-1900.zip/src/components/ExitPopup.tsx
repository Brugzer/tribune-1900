import { X } from 'lucide-react';
import { useState } from 'react';

interface ExitPopupProps {
  isOpen: boolean;
  onClose: () => void;
  onSubmit: (email: string) => void;
}

export default function ExitPopup({ isOpen, onClose, onSubmit }: ExitPopupProps) {
  const [email, setEmail] = useState('');
  const [isSubmitted, setIsSubmitted] = useState(false);

  if (!isOpen) return null;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (email) {
      onSubmit(email);
      setIsSubmitted(true);
      setTimeout(() => {
        onClose();
        setIsSubmitted(false);
        setEmail('');
      }, 2000);
    }
  };

  if (isSubmitted) {
    return (
      <div className="fixed inset-0 z-50 overflow-hidden">
        <div
          className="absolute inset-0 bg-black/80 backdrop-blur-sm"
          onClick={onClose}
        ></div>

        <div className="absolute inset-0 flex items-center justify-center p-4">
          <div className="relative bg-tribune-white border border-tribune-black max-w-md w-full p-8 text-center">
            <h3 className="text-2xl font-serif text-tribune-black mb-2">
              Merci !
            </h3>
            <p className="text-tribune-black/80">
              Nous vous tiendrons informé des prochains clubs.
            </p>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="fixed inset-0 z-50 overflow-hidden">
      <div
        className="absolute inset-0 bg-black/80 backdrop-blur-sm"
        onClick={onClose}
      ></div>

      <div className="absolute inset-0 flex items-center justify-center p-4">
        <div className="relative bg-tribune-beige border border-tribune-black max-w-md w-full">
          <button
            onClick={onClose}
            className="absolute top-4 right-4 text-tribune-black/60 hover:text-tribune-black transition-colors"
          >
            <X className="w-5 h-5" />
          </button>

          <div className="p-8">
            <h3 className="text-3xl font-serif text-tribune-black mb-4">
              Ne manquez pas le maillot de votre club.
            </h3>

            <p className="text-tribune-black/80 mb-6 font-light">
              Inscrivez-vous pour être informé en priorité lorsque votre club sera disponible sur Tribune 1900.
            </p>

            <form onSubmit={handleSubmit} className="space-y-4">
              <input
                type="email"
                required
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                placeholder="Votre email"
                className="w-full bg-tribune-white border border-tribune-black/20 text-tribune-black px-4 py-3 focus:border-tribune-black focus:outline-none transition-colors"
              />

              <button
                type="submit"
                className="w-full bg-tribune-white hover:bg-tribune-white/90 text-tribune-black font-bold py-3 transition-all"
              >
                Je m'inscris
              </button>
            </form>
          </div>
        </div>
      </div>
    </div>
  );
}
