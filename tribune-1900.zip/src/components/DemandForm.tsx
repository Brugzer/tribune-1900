import { useState } from 'react';
import { ClubDemand, SPORTS, SIZES, JERSEY_TYPES } from '../types/demand';
import { Check, Loader } from 'lucide-react';

interface DemandFormProps {
  onSubmit: (demand: ClubDemand) => Promise<void>;
}

export default function DemandForm({ onSubmit }: DemandFormProps) {
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [isSuccess, setIsSuccess] = useState(false);
  const [formData, setFormData] = useState<ClubDemand>({
    firstName: '',
    lastName: '',
    email: '',
    phone: '',
    sport: 'Football',
    clubName: '',
    clubCity: '',
    size: 'M',
    sizeType: 'homme',
    jerseyTypes: [],
    comment: '',
    notifyAvailable: true,
    acceptContact: true,
  });

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsSubmitting(true);

    try {
      await onSubmit(formData);
      setIsSuccess(true);
      setFormData({
        firstName: '',
        lastName: '',
        email: '',
        phone: '',
        sport: 'Football',
        clubName: '',
        clubCity: '',
        size: 'M',
        sizeType: 'homme',
        jerseyTypes: [],
        comment: '',
        notifyAvailable: true,
        acceptContact: true,
      });

      setTimeout(() => setIsSuccess(false), 5000);
    } catch (error) {
      console.error('Error submitting form:', error);
    } finally {
      setIsSubmitting(false);
    }
  };

  if (isSuccess) {
    return (
      <section id="form" className="bg-tribune-beige py-16 sm:py-24">
        <div className="max-w-2xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="bg-tribune-white border border-tribune-black p-8 sm:p-12 text-center">
            <Check className="w-12 h-12 sm:w-16 sm:h-16 text-tribune-black mx-auto mb-4 sm:mb-6" />
            <h3 className="text-2xl sm:text-3xl font-serif text-tribune-black mb-3 sm:mb-4">
              Votre choix a bien été pris en compte
            </h3>
            <p className="text-tribune-black/80 text-base sm:text-lg leading-relaxed">
              Merci pour votre intérêt ! Nous vous contacterons en priorité dès que le maillot de votre club sera disponible.
            </p>
          </div>
        </div>
      </section>
    );
  }

  return (
    <section id="form" className="bg-tribune-beige py-16 sm:py-24">
      <div className="max-w-2xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-10 sm:mb-12">
          <h2 className="text-3xl sm:text-4xl md:text-5xl font-serif text-tribune-black mb-3 sm:mb-4 leading-tight px-2">
            Demandez le maillot de votre club
          </h2>
          <p className="text-sm sm:text-base text-tribune-black/60 font-light px-2">
            Laissez vos coordonnées pour être informé en priorité si le stock devient disponible.
          </p>
        </div>

        <form onSubmit={handleSubmit} className="space-y-5 sm:space-y-6">
          <div className="grid sm:grid-cols-2 gap-5 sm:gap-6">
            <div>
              <label className="block text-tribune-black font-light mb-2 text-xs sm:text-sm tracking-wide">
                Prénom
              </label>
              <input
                type="text"
                required
                value={formData.firstName}
                onChange={(e) =>
                  setFormData({ ...formData, firstName: e.target.value })
                }
                placeholder="Votre prénom"
                className="w-full bg-tribune-white border border-tribune-black/20 text-tribune-black px-4 py-3 focus:border-tribune-black focus:outline-none transition-colors"
              />
            </div>

            <div>
              <label className="block text-tribune-black font-light mb-2 text-sm tracking-wide">
                Nom
              </label>
              <input
                type="text"
                required
                value={formData.lastName}
                onChange={(e) =>
                  setFormData({ ...formData, lastName: e.target.value })
                }
                placeholder="Votre nom"
                className="w-full bg-tribune-white border border-tribune-black/20 text-tribune-black px-4 py-3 focus:border-tribune-black focus:outline-none transition-colors"
              />
            </div>
          </div>

          <div>
            <label className="block text-tribune-black font-light mb-2 text-sm tracking-wide">
              Email
            </label>
            <input
              type="email"
              required
              value={formData.email}
              onChange={(e) =>
                setFormData({ ...formData, email: e.target.value })
              }
              placeholder="Votre adresse email"
              className="w-full bg-tribune-white border border-tribune-black/20 text-tribune-black px-4 py-3 focus:border-tribune-black focus:outline-none transition-colors"
            />
          </div>

          <div>
            <label className="block text-tribune-black font-light mb-2 text-sm tracking-wide">
              Téléphone (optionnel)
            </label>
            <input
              type="tel"
              value={formData.phone}
              onChange={(e) =>
                setFormData({ ...formData, phone: e.target.value })
              }
              placeholder="Pour être informé plus rapidement si le club est disponible"
              className="w-full bg-tribune-white border border-tribune-black/20 text-tribune-black px-4 py-3 focus:border-tribune-black focus:outline-none transition-colors"
            />
          </div>

          <div>
            <label className="block text-tribune-black font-light mb-2 text-sm tracking-wide">
              Sport
            </label>
            <select
              required
              value={formData.sport}
              onChange={(e) =>
                setFormData({ ...formData, sport: e.target.value })
              }
              className="w-full bg-tribune-white border border-tribune-black/20 text-tribune-black px-4 py-3 focus:border-tribune-black focus:outline-none transition-colors"
            >
              {SPORTS.map((sport) => (
                <option key={sport} value={sport}>
                  {sport}
                </option>
              ))}
            </select>
          </div>

          <div className="grid sm:grid-cols-2 gap-6">
            <div>
              <label className="block text-tribune-black font-light mb-2 text-sm tracking-wide">
                Nom du club
              </label>
              <input
                type="text"
                required
                value={formData.clubName}
                onChange={(e) =>
                  setFormData({ ...formData, clubName: e.target.value })
                }
                placeholder="Ex : ES Wolfisheim"
                className="w-full bg-tribune-white border border-tribune-black/20 text-tribune-black px-4 py-3 focus:border-tribune-black focus:outline-none transition-colors"
              />
            </div>

            <div>
              <label className="block text-tribune-black font-light mb-2 text-sm tracking-wide">
                Ville du club
              </label>
              <input
                type="text"
                required
                value={formData.clubCity}
                onChange={(e) =>
                  setFormData({ ...formData, clubCity: e.target.value })
                }
                placeholder="Ville ou département"
                className="w-full bg-tribune-white border border-tribune-black/20 text-tribune-black px-4 py-3 focus:border-tribune-black focus:outline-none transition-colors"
              />
            </div>
          </div>

          <div>
            <label className="block text-tribune-black font-light mb-2 text-sm tracking-wide">
              Type de maillot <span className="text-tribune-black/60 text-xs">(vous pouvez sélectionner les deux)</span>
            </label>
            <div className="grid sm:grid-cols-2 gap-4">
              {JERSEY_TYPES.map((type) => {
                const isSelected = formData.jerseyTypes.includes(type.value);
                return (
                  <button
                    key={type.value}
                    type="button"
                    onClick={() => {
                      if (isSelected) {
                        setFormData({
                          ...formData,
                          jerseyTypes: formData.jerseyTypes.filter((t) => t !== type.value),
                        });
                      } else {
                        setFormData({
                          ...formData,
                          jerseyTypes: [...formData.jerseyTypes, type.value],
                        });
                      }
                    }}
                    className={`p-4 border transition-all text-left ${
                      isSelected
                        ? 'bg-tribune-white border-tribune-black ring-2 ring-tribune-black'
                        : 'bg-tribune-white border-tribune-black/20 hover:border-tribune-black'
                    }`}
                  >
                    <div className="font-medium text-tribune-black mb-1 flex items-center justify-between">
                      {type.label}
                      {isSelected && (
                        <Check className="w-5 h-5 text-tribune-black" />
                      )}
                    </div>
                    <div className="text-xs text-tribune-black/60 font-light">
                      {type.description}
                    </div>
                  </button>
                );
              })}
            </div>
          </div>

          <div>
            <label className="block text-tribune-black font-light mb-2 text-sm tracking-wide">
              Type de taille
            </label>
            <div className="grid grid-cols-2 gap-4 mb-4">
              <button
                type="button"
                onClick={() => setFormData({ ...formData, sizeType: 'homme' })}
                className={`py-3 border transition-all ${
                  formData.sizeType === 'homme'
                    ? 'bg-tribune-black border-tribune-black text-tribune-white font-bold'
                    : 'bg-tribune-white border-tribune-black/20 text-tribune-black/80 hover:border-tribune-black'
                }`}
              >
                Homme
              </button>
              <button
                type="button"
                onClick={() => setFormData({ ...formData, sizeType: 'femme' })}
                className={`py-3 border transition-all ${
                  formData.sizeType === 'femme'
                    ? 'bg-tribune-black border-tribune-black text-tribune-white font-bold'
                    : 'bg-tribune-white border-tribune-black/20 text-tribune-black/80 hover:border-tribune-black'
                }`}
              >
                Femme
              </button>
            </div>
          </div>

          <div>
            <label className="block text-tribune-black font-light mb-2 text-xs sm:text-sm tracking-wide">
              Taille souhaitée
            </label>
            <div className="grid grid-cols-3 sm:grid-cols-6 gap-2 sm:gap-3">
              {SIZES.map((size) => (
                <button
                  key={size}
                  type="button"
                  onClick={() => setFormData({ ...formData, size })}
                  className={`py-2.5 sm:py-3 border transition-all text-sm sm:text-base ${
                    formData.size === size
                      ? 'bg-tribune-black border-tribune-black text-tribune-white font-bold'
                      : 'bg-tribune-white border-tribune-black/20 text-tribune-black/80 hover:border-tribune-black'
                  }`}
                >
                  {size}
                </button>
              ))}
            </div>
          </div>

          <div>
            <label className="block text-tribune-black font-light mb-2 text-sm tracking-wide">
              Commentaire (optionnel)
            </label>
            <textarea
              value={formData.comment}
              onChange={(e) =>
                setFormData({ ...formData, comment: e.target.value })
              }
              placeholder="Des informations supplémentaires à nous communiquer ?"
              rows={4}
              className="w-full bg-tribune-white border border-tribune-black/20 text-tribune-black px-4 py-3 focus:border-tribune-black focus:outline-none transition-colors resize-none"
            />
          </div>

          <div className="space-y-3 pt-4">
            <label className="flex items-start space-x-3 cursor-pointer group">
              <input
                type="checkbox"
                checked={formData.notifyAvailable}
                onChange={(e) =>
                  setFormData({
                    ...formData,
                    notifyAvailable: e.target.checked,
                  })
                }
                className="mt-1 w-5 h-5 bg-tribune-white border-tribune-black/20 text-amber-600 focus:ring-amber-600"
              />
              <span className="text-tribune-black/80 text-sm font-light group-hover:text-tribune-black transition-colors">
                Je souhaite être informé dès que ce club est disponible
              </span>
            </label>

            <label className="flex items-start space-x-3 cursor-pointer group">
              <input
                type="checkbox"
                checked={formData.acceptContact}
                onChange={(e) =>
                  setFormData({
                    ...formData,
                    acceptContact: e.target.checked,
                  })
                }
                className="mt-1 w-5 h-5 bg-tribune-white border-tribune-black/20 text-amber-600 focus:ring-amber-600"
              />
              <span className="text-tribune-black/80 text-sm font-light group-hover:text-tribune-black transition-colors">
                J'accepte d'être contacté par Tribune 1900
              </span>
            </label>
          </div>

          <button
            type="submit"
            disabled={isSubmitting}
            className="w-full bg-tribune-black hover:bg-tribune-black/90 disabled:bg-tribune-black/50 text-tribune-white font-bold text-base sm:text-lg py-3.5 sm:py-4 transition-all flex items-center justify-center space-x-2 mt-8"
          >
            {isSubmitting ? (
              <>
                <Loader className="w-5 h-5 animate-spin" />
                <span>Envoi en cours...</span>
              </>
            ) : (
              <span>Je manifeste mon intérêt</span>
            )}
          </button>
        </form>
      </div>
    </section>
  );
}
