export default function HowItWorks() {
  const steps = [
    {
      number: '1',
      title: 'Vous nous indiquez votre club',
      description: 'Remplissez le formulaire avec les informations de votre club',
    },
    {
      number: '2',
      title: 'Nous créons l\'édition collector',
      description: 'Réédition historique ou création originale : nous concevons un maillot unique qui célèbre le patrimoine du club',
    },
    {
      number: '3',
      title: 'Vous êtes informé en priorité',
      description: 'Dès que l\'édition collector est prête, vous recevez une notification en exclusivité',
    },
  ];

  return (
    <section className="bg-tribune-black py-16 sm:py-24">
      <div className="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-12 sm:mb-16">
          <h2 className="text-3xl sm:text-4xl md:text-5xl font-serif text-tribune-white mb-4 leading-tight px-2">
            Comment ça fonctionne ?
          </h2>
          <p className="text-tribune-white/70 text-base sm:text-lg font-light max-w-2xl mx-auto mt-4 px-2">
            Nous créons des rééditions historiques et des pièces collectors qui célèbrent l'histoire des clubs amateurs
          </p>
        </div>

        <div className="grid md:grid-cols-3 gap-8 sm:gap-10">
          {steps.map((step, index) => (
            <div
              key={index}
              className="relative bg-tribune-white/5 border border-tribune-white/10 p-6 sm:p-8 text-center"
            >
              <div className="absolute -top-5 sm:-top-6 left-1/2 -translate-x-1/2 w-10 h-10 sm:w-12 sm:h-12 bg-tribune-white flex items-center justify-center">
                <span className="text-xl sm:text-2xl font-serif text-tribune-black font-bold">
                  {step.number}
                </span>
              </div>

              <div className="mt-6">
                <h3 className="text-lg sm:text-xl font-serif text-tribune-white mb-3">
                  {step.title}
                </h3>
                <p className="text-sm sm:text-base text-tribune-white/60 font-light leading-relaxed">
                  {step.description}
                </p>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
