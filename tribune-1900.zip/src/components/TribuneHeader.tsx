export default function TribuneHeader() {
  return (
    <header className="fixed top-0 left-0 right-0 z-50 bg-tribune-white/95 backdrop-blur-sm border-b border-tribune-black/10">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16 sm:h-20">
          <img
            src="/TRIBUNE_1900-.png"
            alt="Tribune 1900"
            className="h-12 sm:h-16 w-auto"
          />
          <h1 className="absolute left-1/2 -translate-x-1/2 text-lg sm:text-2xl lg:text-3xl font-serif text-tribune-black tracking-wide whitespace-nowrap">
            TRIBUNE 1900
          </h1>
        </div>
      </div>
    </header>
  );
}
