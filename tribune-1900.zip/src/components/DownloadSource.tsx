import { Download } from 'lucide-react';

export function DownloadSource() {
  const handleDownload = async () => {
    try {
      const response = await fetch('/tribune-1900-source.zip');
      const blob = await response.blob();
      const url = window.URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = 'tribune-1900-source.zip';
      document.body.appendChild(a);
      a.click();
      window.URL.revokeObjectURL(url);
      document.body.removeChild(a);
    } catch (error) {
      console.error('Erreur de téléchargement:', error);
    }
  };

  return (
    <button
      onClick={handleDownload}
      className="fixed bottom-4 right-4 bg-blue-600 hover:bg-blue-700 text-white px-4 py-2 rounded-lg shadow-lg flex items-center gap-2 transition-colors z-50"
    >
      <Download size={20} />
      Télécharger le code source
    </button>
  );
}
