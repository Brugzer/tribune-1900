export default function TribuneFooter() {
  return (
    <footer className="bg-tribune-white border-t border-tribune-black/10 py-12 sm:py-16">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center">
          <div className="flex items-center justify-center mb-4 sm:mb-6">
            <img
              src="/TRIBUNE_1900-.png"
              alt="Tribune 1900"
              className="h-16 sm:h-20 w-auto"
            />
          </div>

          <p className="text-sm sm:text-base text-tribune-black/60 font-light mb-6 sm:mb-8 max-w-md mx-auto px-4">
            Suivez-nous pour découvrir les prochains clubs disponibles.
          </p>

          <div className="border-t border-tribune-black/10 pt-6 sm:pt-8">
            <p className="text-tribune-black/40 text-xs sm:text-sm font-light">
              © 2024 Tribune 1900. Tous droits réservés.
            </p>
          </div>
        </div>
      </div>
    </footer>
  );
}
