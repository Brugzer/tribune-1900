/*
  # Update jersey_types to support multiple selections

  1. Changes
    - Drop existing jersey_type column
    - Add new jersey_types column as text array
    - This allows users to select both historic and collector maillots
  
  2. Notes
    - Existing data will need to be migrated manually if there is any
    - The new column supports selecting one or both jersey types
*/

-- Remove old column and add new array column
DO $$
BEGIN
  -- Drop old column if exists
  IF EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'demand_responses' AND column_name = 'jersey_type'
  ) THEN
    ALTER TABLE demand_responses DROP COLUMN jersey_type;
  END IF;

  -- Add new array column if it doesn't exist
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'demand_responses' AND column_name = 'jersey_types'
  ) THEN
    ALTER TABLE demand_responses 
    ADD COLUMN jersey_types text[] NOT NULL DEFAULT '{}';
  END IF;
END $$;
