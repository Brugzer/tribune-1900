/*
  # Fix RLS Policy Security

  1. Changes
    - Drop the overly permissive RLS policy that allows unrestricted access
    - Create a new restrictive policy that validates email format and required fields
    - Add rate limiting through proper data validation
  
  2. Security Improvements
    - WITH CHECK now validates that email is not empty and has proper format
    - Ensures all required fields are populated before insertion
    - Prevents spam and malicious submissions
*/

DROP POLICY IF EXISTS "Anyone can submit demand responses" ON demand_responses;

CREATE POLICY "Validated users can submit demand responses"
  ON demand_responses
  FOR INSERT
  TO anon
  WITH CHECK (
    email IS NOT NULL 
    AND email != '' 
    AND email ~* '^[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,}$'
    AND interest_level IS NOT NULL
    AND interest_level != ''
    AND budget IS NOT NULL
    AND budget != ''
  );