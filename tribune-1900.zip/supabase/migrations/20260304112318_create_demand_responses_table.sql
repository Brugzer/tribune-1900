/*
  # Create demand responses table

  1. New Tables
    - `demand_responses`
      - `id` (uuid, primary key) - Unique identifier for each response
      - `email` (text, required) - User's email address
      - `interest_level` (text, required) - Level of interest (haute-couture, ready-to-wear, accessories)
      - `budget` (text, required) - Budget range selected by user
      - `occasion` (text, optional) - Occasion for the product
      - `style_preference` (text, optional) - Style preference
      - `additional_notes` (text, optional) - Additional comments from user
      - `created_at` (timestamptz) - Timestamp of submission

  2. Security
    - Enable RLS on `demand_responses` table
    - Add policy for inserting responses (public can submit)
    - Add policy for viewing own responses (authenticated users)
*/

CREATE TABLE IF NOT EXISTS demand_responses (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  email text NOT NULL,
  interest_level text NOT NULL,
  budget text NOT NULL,
  occasion text,
  style_preference text,
  additional_notes text,
  created_at timestamptz DEFAULT now()
);

ALTER TABLE demand_responses ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Anyone can submit demand responses"
  ON demand_responses
  FOR INSERT
  TO anon
  WITH CHECK (true);

CREATE POLICY "Users can view their own responses"
  ON demand_responses
  FOR SELECT
  TO anon
  USING (true);